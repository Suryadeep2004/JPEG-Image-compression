const RegisterData=[
    {register:'x0', hex:'0x00000000', binary: '00000000', integer: '0'},
    {register:'x0', hex:'0x00000000', binary: '00000000', integer: '0'},
    {register:'x0', hex:'0x00000000', binary: '00000000', integer: '0'},
    {register:'x0', hex:'0x00000000', binary: '00000000', integer: '0'},
    {register:'x0', hex:'0x00000000', binary: '00000000', integer: '0'},
    {register:'x0', hex:'0x00000000', binary: '00000000', integer: '0'},
    {register:'x0', hex:'0x00000000', binary: '00000000', integer: '0'},
    {register:'x0', hex:'0x00000000', binary: '00000000', integer: '0'},

]
export default RegisterData;